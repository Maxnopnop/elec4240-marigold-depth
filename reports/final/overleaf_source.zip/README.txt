Open final_report.tex as the main document and use pdfLaTeX. The unchanged official CVPR2022 style is embedded. The figures directory must remain beside the source.
