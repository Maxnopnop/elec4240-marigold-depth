ELEC4240 final-report source supplement
Authors: HO, Chun Wai 21053878; Tong, Man Hung 21064669; MA, Shenhan 21041382.
Start with FINAL_REPRODUCE.md, REFERENCES.md and CORRECTIONS.md.
Included: project source, protocols, selected manifests/summaries, final diagnostic figures.
Excluded: datasets, weights, raw predictions, installed packages, full per-image result matrices and Git history.
Completion markers are historical evidence, not substitutes for excluded raw artifacts.
Published result links in README.md may refer to files kept only in the full repository.
Exact replay requires separately prepared assets and upstream runs; a fresh reproduction must use separate result directories.
Private repository: https://github.com/Maxnopnop/elec4240-marigold-depth
Original six-test conclusions remain unchanged; the final extension is exploratory.
